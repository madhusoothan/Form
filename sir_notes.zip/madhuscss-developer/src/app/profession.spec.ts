import { Profession } from './profession';

describe('Profession', () => {
  it('should create an instance', () => {
    expect(new Profession()).toBeTruthy();
  });
});
